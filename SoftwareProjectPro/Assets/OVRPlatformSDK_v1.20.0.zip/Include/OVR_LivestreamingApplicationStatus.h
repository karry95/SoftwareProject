// This file was @generated with LibOVRPlatform/codegen/main. Do not modify it!

#ifndef OVR_LIVESTREAMINGAPPLICATIONSTATUS_H
#define OVR_LIVESTREAMINGAPPLICATIONSTATUS_H

#include "OVR_Platform_Defs.h"
#include <stdbool.h>

typedef struct ovrLivestreamingApplicationStatus *ovrLivestreamingApplicationStatusHandle;

OVRP_PUBLIC_FUNCTION(bool) ovr_LivestreamingApplicationStatus_GetStreamingEnabled(const ovrLivestreamingApplicationStatusHandle obj);

#endif
