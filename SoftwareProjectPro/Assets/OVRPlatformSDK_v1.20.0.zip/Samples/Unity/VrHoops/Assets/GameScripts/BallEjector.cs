﻿using UnityEngine;
using System.Collections;

public class BallEjector : MonoBehaviour {

}
